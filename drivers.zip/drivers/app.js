(function() {
  var app = angular.module('gemStore', ['ngMaterial', 'ngMessages']);


  app.controller('ReviewCtrl', function($scope, $http, $timeout, $q, $document){
    this.review = {};
    var self = this;
    var datePicker = {};
    // list of `state` value/display objects
    self.states = this.loadAll;

    this.dateChange = function(event){
      this.review['date'] = event.target.value;
    };

    this.addReview = function(){
      this.review['user'] = 'pviquez';
      var that = this;
      $http.post("/conductores/get", this.review)
      .success(function(data, status, headers, config) {
          $scope.data = data;
          alert('Datos Ingresados Exitosamente.');
          that.review = {ID:'123456789',liters:1,km:1,amount:1};
      }).error(function(data, status, headers, config) {
          $scope.status = status;
      });
    };

    var self = this;
    // list of `state` value/display objects


    this.loadAll = function() {
      var allPlates = '123456789, 265-047, 265-049, 265-070, 265-077, 265-079, 265-088, 265-089, 265-090, 265-093, 265-094, 265-095, 265-101, 265-102, 265-107, 265-111, 265-114, 265-127, 265-130, 265-131, 265-132, 265-134, 265-135, 265-136, 265-137, 265-139, 265-144, 265-145, 149, 150, 151, 265-152, 265-155, 265-156, 265-157, 265-160, 162, 163, 265-164, 265-166, 265-167, 265-170, 265-171, 265-172, 173, 174, 265-175, 265-176, 265-177, 265-179, 265-180, 265-181, 265-182, 265-183, 265-185, 265-186, 265-188, 265-189, 265-190, 191, 265-194, 265-198, 265-199, 265-200, 265-201, 205, 206, 265-208, 265-210, 265-211, 265-212, 265-213, 265-214, 265-215, 265-216, 265-217, 265-219, 265-220, 265-221, 265-222, 265-224, 265-226, 265-227, 265-228, 231, 232, 233, 234, 235, 265-236, 265-237, 265-238, 265-074, 265-087, 265-091, 265-099, 265-108, 265-119, 265-129, 265-133, 265-140, 265-142, 265-154, 265-158, 265-159, 265-161, 265-168, 265-169, 265-178, 265-184, 265-192, 265-193, 265-195, 196, 197, 265-202, 265-204, 265-207, 265-209, 265-218, 265-230, 265-045, 265-187, 265-223, 265-079, 229, 265-245, 265-246, 706598, 237-221, 139-008, 265-243, 265-146';
      return allPlates.split(/, +/g).map( function (plate) {
        return {
          value: plate.toLowerCase(),
          display: plate
        };
      });
    };

    self.states        = this.loadAll();
    self.selectedItem  = null;
    self.searchText    = null;


    this.createFilterFor = function(query) {
      var lowercaseQuery = angular.lowercase(query);
      return function filterFn(state) {
        return (state.value.indexOf(lowercaseQuery) === 0);
      };
    };
    
    this.querySearch = function(query) {
      var results = query ? self.states.filter( self.createFilterFor(query) ) : self.states;
      var deferred = $q.defer();
      $timeout(function () { deferred.resolve( results ); }, Math.random() * 1000, false);
      return deferred.promise;
    };

    self.querySearch   = this.querySearch;

    this.selectedItemChange =  function(item) {
      this.review.ID = item.value;
      console.log(item.value);
    }
  });
})();
